export class Department {
    id : string;
    name : string;
}