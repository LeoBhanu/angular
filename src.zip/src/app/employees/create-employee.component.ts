import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Employee } from '../models/employee.model';
import { Department } from '../models/department.model';


@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {
photo= false;
  gender = 'male';
  cp = 'phone';
  fullname = '';
  email = '';
  phone = '';
  // department : Department[] = [
  //   {id : "it" , name : "it"},
  //   {id : "hr" , name : "hr"},
  //   {id : "payroll" , name : "payroll"},
  //   {id : "helpdesk" , name : "help desk"}
  // ];
  dob  ='';
  pp = '';
  isActive = '';
togglePreview(){
  this.photo=!this.photo;
}
  constructor() { }
 
  ngOnInit(): void {
  }

  saveEmp(emForm : NgForm) : void{

  }
}
