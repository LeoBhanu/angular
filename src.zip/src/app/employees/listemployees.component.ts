import { Component, OnInit } from '@angular/core';
import { Employee } from '../models/employee.model';

@Component({
  selector: 'app-listemployees',
  templateUrl: './listemployees.component.html',
  styleUrls: ['./listemployees.component.css']
})
export class ListemployeesComponent implements OnInit {
  employee : Employee[] = [
    {   id : 1,
      name : 'a',
      gender : 'female',
      email : 'email',
      phone : 12345,
      dob : new Date('05/18/2002'),
      contactPreference :'a@cloudcollab.co',
      depat: 'it',
      isActive : true,
      photopath : 'assets/a.jpg'
    },
    {
      id : 2,
      name : 'b',
      gender : 'male',
      email : 'email',
      phone : 12345678,
      dob : new Date('05/18/2002'),
      contactPreference :'a@cloudcollab.co',
      depat: 'it',
      isActive : true,
      photopath : 'assets/b.jpg'
    },
    {
      id : 1,
      name : 'c',
      gender : 'female',
      email : 'email',
      phone : 987654321,
      dob : new Date('05/18/2002'),
      contactPreference :'a@cloudcollab.co',
      depat: 'it',
      isActive : true,
      photopath : 'assets/c.jpg'
    }
  ]
  constructor() { }

  ngOnInit(): void {
  }

}
